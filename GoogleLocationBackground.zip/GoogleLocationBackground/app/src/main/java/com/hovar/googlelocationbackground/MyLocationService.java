package com.hovar.googlelocationbackground;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.IBinder;
import android.widget.Toast;

import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MyLocationService extends BroadcastReceiver {

    public static final String ACTION_PROCESS_UPDATE="com.hovar.googlelocationbackground.UPDATE_LOCATION";

    @Override
    public void onReceive(Context context, Intent intent) {
        if(intent!=null){
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference myRef = database.getReference("appIsOff");
            final String action = intent.getAction();
            if(ACTION_PROCESS_UPDATE.equals(action)){
                LocationResult result = LocationResult.extractResult(intent);
                if(result!=null){
                    Location location = result.getLastLocation();
                    String location_string = new StringBuilder("Lat: "+location.getLatitude())
                            .append(" , Long: ")
                            .append(location.getLongitude())
                            .toString();
                    try{
                        MainActivity.getInstance().updateTextView(location_string);
                        myRef.setValue(location_string);
                    }catch (Exception ex){
                        Toast.makeText(context, location_string, Toast.LENGTH_SHORT).show();
                        myRef.setValue(location_string);
                    }
                }
            }
            if(intent.getAction().equals(Intent.ACTION_SCREEN_OFF)){
                Toast.makeText(context, "power button pressed",Toast.LENGTH_LONG);
            }
            if(intent.getAction().equals(Intent.ACTION_SCREEN_ON)){
                Toast.makeText(context, "power button pressed ONNNNNN",Toast.LENGTH_LONG);
            }
        }
    }
}
